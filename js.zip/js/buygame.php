<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BUY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    
</head>
<body style="background-image:url('img/wing.png');">
    <table width = "500" border="0" bgcolor = "#9cc4e4" align="center" cellpadding="10">
        <tr align="center">
            <td><img src="img/02.jpg" height = "470"></td>
        </tr>
        <tr>
            <td align="center">
            <div class="alert alert-light" role="alert">NAME GAME</div>
            </td>
        </tr>
        <tr>
            <td align="center">
            <div class="alert alert-info" role="alert">CODE GAME</div>
            </td>
        </tr>
        <tr>
            <td align="center">
            <button type="button" class="btn btn-danger btn-lg btn-block" >Back</button>
            </td>
        </tr>
    </table>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
        crossorigin="anonymous"></script>
</body>
</html>